#ifndef _ERRORS_H_
#define _ERROR_H_

extern char *programname;

extern void fatalerror(char *message);
extern void errormessage(char *message);

#endif